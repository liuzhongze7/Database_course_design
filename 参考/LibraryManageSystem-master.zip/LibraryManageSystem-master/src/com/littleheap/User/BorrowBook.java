package com.littleheap.User;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import com.littleheap.MainInterface;
import com.littleheap.DataBase.TableOperate;
import com.littleheap.Static.Information;

import javax.swing.JTextField;

public class BorrowBook extends JPanel implements ActionListener{
	private JLabel label;
	private JButton back;
	private JTextField tf_classname;
	private JLabel lb_classname;
	private JButton btn_search;

	/**
	 * Create the panel.
	 */
	public BorrowBook() {
		setBackground(new Color(250, 250, 210));
		setLayout(null);
		
		back = new JButton("\u8FD4\u56DE");
		back.setFont(new Font("����", Font.PLAIN, 26));
		back.setBounds(0, 0, 115, 82);
		add(back);
		back.addActionListener(this);
		
		label = new JLabel("\u501F\u4E66\u7CFB\u7EDF");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setFont(new Font("����", Font.BOLD, 40));
		label.setBounds(530, 62, 294, 105);
		add(label);
		
		lb_classname = new JLabel("\u4E66\u5E93\u7C7B\u522B\u540D\u79F0\uFF1A");
		lb_classname.setFont(new Font("����", Font.BOLD, 35));
		lb_classname.setBounds(241, 330, 283, 55);
		add(lb_classname);
		
		tf_classname = new JTextField();
		tf_classname.setFont(new Font("����", Font.BOLD, 35));
		tf_classname.setColumns(10);
		tf_classname.setBounds(502, 320, 526, 75);
		add(tf_classname);
		
		btn_search = new JButton("\u67E5\u8BE2");
		btn_search.setFont(new Font("����", Font.BOLD, 35));
		btn_search.setBounds(558, 567, 251, 80);
		add(btn_search);
		btn_search.addActionListener(this);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == back) {
			MainInterface.BorrowtoUser();
		}else if(e.getSource() == btn_search) {
			
			String classname = tf_classname.getText();
			Information.search_classname = classname;
			
			//��ѯ����ͼ����Ϣ
			if(TableOperate.isExist_Table(classname+"book")) {
				TableOperate.search_classname(tf_classname.getText());		
				MainInterface.BorrowtoBorrowInfo();	
				BorrowBook_Information.setTextArea();	
				tf_classname.setText("");
			}else {
				JOptionPane.showMessageDialog(null, "�����ڸ����", "��ѯʧ��", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
}
