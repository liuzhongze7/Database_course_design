package com.littleheap;

public class Book {
	public String number;
	public String classnumber;
	public String name;
	public String classname;
	public String price;
	public String state;
	public String total;
	public String current;
	public String dateon;
	public String dateoff;
}
