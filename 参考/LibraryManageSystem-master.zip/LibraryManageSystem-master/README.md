# LibraryManageSystem
|界面       | 图片  |
| ------------- |:-------------:|
| 架构设计      |<img width="600" height="400" src="./images/1.png"/>|
| 登录界面      |<img width="500" height="400" src="./images/2.png"/>|
| 管理员登录     |<img width="500" height="400" src="./images/3.png"/>|
| 管理员界面      |<img width="500" height="400" src="./images/4.png"/>|
| 新书录入界面      |<img width="500" height="400" src="./images/5.png"/>|
| 新建书库界面   |<img width="500" height="400" src="./images/6.png"/>|
| 更新旧书界面   |<img width="500" height="400" src="./images/7.png"/>|
| 图书库状态查询界面   |<img width="500" height="400" src="./images/8.png"/>|
| 图书库状态信息显示    |<img width="500" height="400" src="./images/9.png"/>|
| 用户界面   |<img width="500" height="400" src="./images/10.png"/>|
| 用户借书状态显示界面   |<img width="500" height="400" src="./images/11.png"/>|
| 用户还书系统界面    |<img width="500" height="400" src="./images/12.png"/>|
| 用户续借界面     |<img width="500" height="400" src="./images/13.png"/>|
| 用户个人信息界面    |<img width="500" height="400" src="./images/14.png"/>|
