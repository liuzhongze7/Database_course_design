package edu.yangtzeu.lmis.gui;

import javax.swing.JPanel;

public class UserPanel extends JPanel {

}
